function decodeBase64Image(dataString) {
    var matches = dataString.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/),
    response = {};

    if (matches.length !== 3) {
        return new Error('Invalid input string');
    }

    response.type = matches[1];
    response.data = new Buffer(matches[2], 'base64');

    /*var lowerCase = response.toLowerCase();
	if (lowerCase.indexOf("png") !== -1){
		response.extension = "png";	
	} 
	else if (lowerCase.indexOf("jpg") !== -1 || lowerCase.indexOf("jpeg") !== -1)
	{
	    response.extension = "jpg";
	}
	else{
		response.extension = "tiff";	
	} */

	response.format = response.type.split('/');
    return response;
}

exports.decodeBase64Image = decodeBase64Image;
