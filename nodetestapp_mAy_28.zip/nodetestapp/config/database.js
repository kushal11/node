module.exports = {
  'secret':'nodeauthsecret',
  'database': 'mongodb://localhost/node_test_app'
};