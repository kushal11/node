var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt = require('bcrypt-nodejs');
var uniqueValidator = require('mongoose-unique-validator');
    // Apply the uniqueValidator plugin to userSchema.
var mongoosePaginate = require('mongoose-paginate');
// var mongoosePaginate = require('mongoose-query-paginate');

var UserSchema = new Schema({
    firstName:{
        type: String,
        required: [true, 'Firstname is required'],
        validate: [validator, 'Please enter minimum 6 character long.']
    },
    lastName:{
        type: String,
        required: [true, 'Lastname is required'],  
        validate: [validator, 'Please enter minimum 6 character long.']
    },
    username: {
        type: String,
        required: [true, 'Username is required'],
        validate: [validator, 'Please enter minimum 6 character long.'],
        unique: [true, 'Username already exists.']
    },
    email:{
        type: String,
        required: [true, 'Email is required'],  
        unique: true,
        match: [/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/, 'Please fill a valid email address']
        // regex: '/@mongodb\.com$/'
    },
    phone:{
        required: [true, 'Phone is required'],
        type: Number,
        index:true,
        unique: [true, 'phone already exists.'],
    },
    
    password: {
        type: String,
        required: [true, 'Password is required'],
        validate: [validator, 'it should be in minimum length 6.']
    },

    image:{
        type: String,
    },
    
    /*address : {
        type: {
            type:String,
            default:"Point"
        },
        coordinates:{
            type:[Number],
            default:[0,0]
        }
    },*/
    address: {
       type: { type: String },

       coordinates: [Number]
   },
    /*address: { 
        // type: String,
        type: [Number],
        index: { 
            type: '2dsphere', 
        },
        coordinates:{
            type:[Number],
            // default:[0,0]
        }
    },*/
    /*latitude:{
        type:String,
    },
    longitude:{
        type:String,
    }*/

    /*passwordHash:{
        type: String,
        required: true  
    },
    passwordSalt:{
        type: String,
        required: true  
    },
    password:String,
    passwordSalt:String*/
    device_token:{
        type: String,
        default:null
    }
});
UserSchema.plugin(uniqueValidator);

function validator (v) {
  return v.length > 5;
};
function validator_phone (val) {
  return val.length > 9;
};

UserSchema.index({addess: '2dsphere'});

UserSchema.pre('save', function (next) {
    var user = this;

    if (this.isModified('password') || this.isNew) {
        bcrypt.genSalt(10, function (err, salt) {
            if (err) {
                return next(err);
            }
            bcrypt.hash(user.password, salt, null, function (err, hash) {
                if (err) {
                    return next(err);
                }
                user.password = hash;
                next();
            });
        });
    } else {
        return next();
    }
});

UserSchema.methods.comparePassword = function (passw, cb) {
    // var user = this;
    bcrypt.compare(passw, this.password, function (err, isMatch) {
        if (err) {
            return cb(err);
        }
        cb(null, isMatch);
    });
};

UserSchema.plugin( mongoosePaginate );
module.exports = mongoose.model('User', UserSchema);


