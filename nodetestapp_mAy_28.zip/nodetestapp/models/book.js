var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var User = mongoose.model('User');
var BookSchema = new Schema({
  isbn: {
    type: String,
    required: true
  },
  title: {
    type: String,
    required: true
  },
  author: {
    type: String,
    required: true
  },
  publisher: {
    type: String,
    required: true
  },
  user_id:{
    type: Schema.Types.ObjectId, 
    ref: User
  }

});

module.exports = mongoose.model('Book', BookSchema);