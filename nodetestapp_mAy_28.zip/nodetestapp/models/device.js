var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var User = mongoose.model('User');
var Device = new Schema({
    device_token : String,
    platform : String,
    user_id:{
	    type: Schema.Types.ObjectId, 
	    ref: User
	 }
});

var DeviceSchema = mongoose.model('Device', Device);