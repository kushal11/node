'use strict';

var mongoose = require('mongoose'),

User = mongoose.model('User');
var Book = mongoose.model('Book');
var City = mongoose.model('City');
var Device = mongoose.model('Device');


var passport = require('passport');

var config = require('../config/database');

require('../config/passport')(passport);

var express = require('express');
var jwt = require('jsonwebtoken');

var router = express.Router();
var my_mail_func = require('../mail'); // include the module we created
var decodebase6 = require('../decodebase64image'); // include the module we created
var sendAndroid1 = require('../sendAndroid'); // include the module we created
var randomString = require('../randomString'); // include the module we created

var formidable = require('formidable');

var multer = require("multer");
var url = require('url');
// var paginate = require("mongoose-paginate");
// var paginate = require("mongoose-query-paginate");

var fs = require("fs");


var gcm = require('node-gcm');
exports.signup=function(req, res) {

    var newUser = new User({ 
        email: req.body.email,
        password: req.body.password,
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        username: req.body.username,
        phone: req.body.phone,
        "address" : { 
            "type": "Point",
            "coordinates": [req.body.lng, req.body.lat],
        }
    });

    // save the user
    newUser.save(function(err) {
        if (err) {
            return res.json({success: false, msg: err});
        }
        var message = 'New User created successfully';

        my_mail_func.mail_send(req.body.email, message);//mail send 
        
        res.json({success: true, msg: message});
    });
};

exports.adddevice=function(req, res) {
    var token = getToken(req.headers);
    if (token) {
        // var id = JSON.parse(token);
        var decoded = jwt.decode(token, token);
        var user_id = decoded._id;

        /*User.findOneAndUpdate({_id: user_id},{device_token:req.body.device_token},{new: true}, function(err, user) {
            if (err)
            res.send(err);
            res.json(user);
        });*/

        Device.findOneAndUpdate({user_id: user_id},{device_token:req.body.device_token,platform: req.body.platform},{new: true}, function(err, dev) {
            if (err)
            res.send(err);
            res.json(dev);
        });             

        
        
        /*var device = new Device({ 
            user_id: user_id,
            device_token:req.body.device_token,
            platform: req.body.platform,
        });

        // save the user
        device.save(function(err) {
            if (err) {
                return res.json({success: false, msg: err});
            }
            var message = 'Device token added successfully';

            res.json({success: true, msg: message, device:device});
        });*/
    }
    
};

exports.send_notification =  function(req, res){
    var token = getToken(req.headers);
        // var id = JSON.parse(token);
        var decoded = jwt.decode(token, token);
        var user_id = decoded._id;
    Device.find({user_id:user_id}, (err, devices) => {
        if (!err && devices) {
            let androidDevices = [];
            devices.forEach(device => {
                if (device.platform === '2') {
                    sendIos(device.device_token);
                } else if (device.platform === '1') {
                    androidDevices.push(device.device_token);
                }
            });
            // sendAndroid(androidDevices);
            let message = new gcm.Message({
                notification : {
                    title : 'Hello, World!'
                }
            });
            let sender = new gcm.sender('AAAAS9SKvO0:APA91bEb_g7Cw_8USV5MybdeFvTh7a8aDXJkezUaLbLispIVpoAYnnsmDEYDmU9CYKxVa9P24EUVATHzBwcB0wLgBCNePfr8yz0MlaqNAD85vqsyneVPS7Kwbr-VN-GOepWWEZZy-Kbq');
         
            sender.send(message, {
                registrationTokens : androidDevices
            }, function(err, response) {
                if (err) {
                    console.error(err);
                } else {
                    console.log(response);
                }
            });
            res.send(200);
        } else {
            res.send(500);
        }
    });
};


 
/*function sendAndroid(devices) {
    let message = new gcm.Message({
        notification : {
            title : 'Hello, World!'
        }
    });
 
    let sender = new gcm.sender('AAAAS9SKvO0:APA91bEb_g7Cw_8USV5MybdeFvTh7a8aDXJkezUaLbLispIVpoAYnnsmDEYDmU9CYKxVa9P24EUVATHzBwcB0wLgBCNePfr8yz0MlaqNAD85vqsyneVPS7Kwbr-VN-GOepWWEZZy-Kbq');
 
    sender.send(message, {
        registrationTokens : devices
    }, function(err, response) {
        if (err) {
            console.error(err);
        } else {
            console.log(response);
        }
    });
}*/

exports.signin =  function(req, res){

    var re = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    var ov={};

    if(!isNaN(req.body.na))
    {
        ov['phone']=req.body.na;
    }
    else if( re.test(req.body.na))
    {
        ov['email']=req.body.na;
    }
    else{
        ov['username']=req.body.na;       
    }
    
    User.findOne(ov, function(err, user) {
            // console.log(user);
    if (err) throw err;    
        if (!user) {
            res.status(401).send({success: false, msg: 'Authentication failed. User not found.'});
        } 
        else {
            // check if password matches
            user.comparePassword(req.body.password, function (err, isMatch) {
    
                if (isMatch && !err) {
                    // if user is found and password is right create a token
                    // var token = jwt.sign(user, config.secret);

                    var token = jwt.sign(user.toJSON(), config.secret);
                    /*const token = jwt.sign(user.toJSON(), config.secret, {
                        expiresIn: 604800 // 1 week
                    });*/
                    // return the information including token as JSON
                    res.json({success: true, token: 'JWT ' + token});
                } 
                else {
                    res.status(401).send({success: false, msg: 'Authentication failed. Wrong password.'});
                }
            });
        }
    });
};

exports.users =   function(req, res) {
      //var token = req.headers['x-access-token'];
    var token = getToken(req.headers);
    if (token) {
       // var id = JSON.parse(token);
         var decoded = jwt.decode(token, token);
         var user_id = decoded._id;
       // console.log(decoded._id);

        /*User.find(function (err, users) {
          if (err) return next(err);
          res.json(users);
        }).remove({ $nor: [ { _id: user_id } ] });*/
        

        /*var options = {
          perPage: 1,
          delta  : 3,
          page   : req.query.p
        };
        var query = User.find().sort({username: 'asc'}).remove({ $nor: [ { _id: user_id } ] });
        console.log(query);
        query.paginate(options, function(err, resp) {
          console.log(resp); // => res = {
            return res.json(resp);
            //  options: options,               // paginate options
            //  results: [Document, ...],       // mongoose results
            //  current: 5,                     // current page number
            //  last: 12,                       // last page number
            //  prev: 4,                        // prev number or null
            //  next: 6,                        // next number or null
            //  pages: [ 2, 3, 4, 5, 6, 7, 8 ], // page numbers
            //  count: 125                      // document count
          //};
        });*/


        var url_parts = url.parse(req.url, true);
        var query = url_parts.query;

        if(query.count)
        {
            query.count = parseInt(query.count);   
        }else{
            query.count = 10;
        }

        if(query.page)
        {
            query.page = parseInt((query.page -1 ) * query.count);   
        }
        else
        {
            query.page = 0;   
        }
        
        //working it
        User.find(function (err, users) {
            if (err) throw err;
            res.json(users);
        }).remove({ $nor: [ { _id: user_id } ] }).sort({username:'asc'}).skip(query.page).limit(query.count);
        // db.users.find().skip(pagesize*(n-1)).limit(pagesize)
        //working it
    } 
    else {
        return res.status(403).send({success: false, msg: 'Unauthorized.'});
    }
};

exports.addcity = function(req, res){
    
    var cityModel     = new City({
       "loc": { 
            "type": "Point",
            "coordinates": [req.body.lng, req.body.lat],
        }
     }); 
  
   cityModel.save(function (err) {
     if (err)
       res.send(err);

     res.json({msg:"Add Successful."});
   });
};

exports.getcity = function(req, res){
    City.aggregate(
    [
       { 
            "$geoNear": {
               "near": {
                   "type": "Point",
                   "coordinates": [76.712071, 30.735547]
               },
              "distanceField": "distance",
               "spherical": true,
               "maxDistance": 1000000
            }
        }
    ],
    
    function(err,results) {
        if (err) {
            console.log(err);
            throw err;
        }
        res.json(results);
    });

        
    

    
};
exports.get_users_by_address = function(req, res){
    
    var token = getToken(req.headers);
    if(token){
        var decoded = jwt.decode(token, token);
        var user_id = decoded._id;
        var latitude = decoded.latitude;
        var longitude = decoded.longitude;
    }

    User.aggregate([
        { "$geoNear": {
           "near": {
               "type": "Point",
               "coordinates": [76.753076, 30.713565]
           },
           "distanceField": "distance",
           "spherical": true,
           "maxDistance": 1000000
       }}
   ],
   function(err,results) {
     if (err) {
         console.log(err);
         throw err;
     }
     res.json(results);
   }
   );
    
}




function getDistanceFromLatLonInKm(lat1,lon1,lat2,lon2) {
    var R = 6371; // Radius of the earth in km
    var dLat = deg2rad(lat2-lat1);  // deg2rad below
    var dLon = deg2rad(lon2-lon1); 
    var a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
        Math.sin(dLon/2) * Math.sin(dLon/2)
        ; 
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    var d = R * c; // Distance in km
    return d;
}

function deg2rad(deg) {
  return deg * (Math.PI/180)
}

exports.edit_a_user = function(req, res) {
    
    var updatedata = {};
    updatedata = req.body;
    // string generated by canvas.toDataURL()
    if(req.body.image!='' && typeof req.body.image!='undefined'){

        User.findById(req.params.userId, function(err, user_read) {
            if (err)
            res.send(err);
            if(user_read.image != '' && fs.existsSync("./public/images/"+user_read.image))
            {
                fs.unlink("public/images/"+user_read.image);
            }
        });

        var imageBuffer = decodebase6.decodeBase64Image(req.body.image);
        var new_image_name =  randomString.randomString()+'.'+imageBuffer.format[1];
        fs.writeFile("./public/images/"+new_image_name, imageBuffer.data);
        updatedata['image'] = new_image_name;
        /*var storage = multer.diskStorage({
           destination: (req, file, cb) => {
             cb(null, './')
           },
           filename: (req, file, cb) => {
             cb(null, file.fieldname + '-' + Date.now())
           }
        });

        var upload = multer({ storage : storage}).single('image');

        upload(req,res,function(err) {
               if(err) {
                   return res.end("Error uploading file.");
               }

        console.log("File is uploaded");
           });
        updatedata['image'] = req.body.image;*/
    }
    
    User.findOneAndUpdate({_id: req.params.userId}, updatedata, {new: true}, function(err, user) {
        if (err)
        res.send(err);
        res.json(user);
    });
};

exports.register_book = function (req, res){
    var token = getToken(req.headers);
    if (token) {
        var decoded = jwt.decode(token, token);
        var user_id = decoded._id;
        var ov = {};
        ov = req.body;
        ov['user_id']  = user_id;
        var new_task = new Book(ov);
          new_task.save(function(err, task) {
            if (err)
              res.send(err);
            res.json(task);
          });
    } 
    else {
        return res.status(403).send({success: false, msg: 'Unauthorized.'});
    }
};

exports.books = function(req, res){
    var token = getToken(req.headers);
    if (token) {
        var decoded = jwt.decode(token, token);
        var user_id = decoded._id;

        /*Book.find({}).populate('user_id'). // only works if we pushed refs to children
            exec(function (err, person) {
           if (err) return handleError(err);
            res.send(person);
           
         });*/
        User.aggregate([
                        {   
                            $match: { 
                                _id: mongoose.Types.ObjectId(user_id), 
                                email: 'ft@mailinator.com'
                            } 
                        }, 
                        {
                            $lookup:{
                                from:'books',
                                localField:'_id',
                                foreignField:'user_id',
                                as:'userbooks'
                            }
                        },
                        {$skip: 2}
                    ]).exec(function(err, results){
                            console.log(results);
                            res.json(results);
                        });
        } 
    else {
        return res.status(403).send({success: false, msg: 'Unauthorized.'});
    }
};
exports.registerSocial = function (req, res) {
    User.findOne({ 'email': req.body.email }, (error, existing_user) => {
        
        if (existing_user) {
            // res.send(null, UserTransformer.transform(existing_user));
            User.findOneAndUpdate({ 'email': req.body.email }, {
                username: req.body.username,
                email: req.body.email,
                phone: req.body.phone,
                // image: req.body.image,
                email_verified: true,
                facebook_id: req.body.facebook_id,
            }, {new: true}, function(err, user) {
                if (err)
                  res.send(err);
                res.json(user);
            });
        } 
        else 
        {
            let newUser = new User({
                username: req.body.username,
                email: req.body.email,
                phone: req.body.phone,
                // image: req.body.image,
                email_verified: true,
                facebook_id: req.body.facebook_id,
            });
            
            newUser.save((error, new_user) => {
                res.send(null, UserTransformer.transform(new_user));
                Email.welcome(new_user);
                return UserTransformer.transform(new_user);
            });
        }
    });
}

/*exports.create_a_task = function(req, res) {
  var new_task = new Task(req.body);
  new_task.save(function(err, task) {
    if (err)
      res.send(err);
    res.json(task);
  });
};


exports.read_a_task = function(req, res) {
  Task.findById(req.params.taskId, function(err, task) {
    if (err)
      res.send(err);
    res.json(task);
  });
};


exports.update_a_task = function(req, res) {
  Task.findOneAndUpdate({_id: req.params.taskId}, req.body, {new: true}, function(err, task) {
    if (err)
      res.send(err);
    res.json(task);
  });
};


exports.delete_a_user = function(req, res) {
  Task.remove({
    _id: req.params.taskId
  }, function(err, task) {
    if (err)
      res.send(err);
    res.json({ message: 'Task successfully deleted.' });
  });
};*/
