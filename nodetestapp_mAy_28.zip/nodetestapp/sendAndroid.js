var gcm = require('node-gcm');
 
function sendAndroid(devices) {
    let message = new gcm.Message({
        notification : {
            title : 'Hello, World!'
        }
    });
 
    let sender = new gcm.sender('AAAAS9SKvO0:APA91bEb_g7Cw_8USV5MybdeFvTh7a8aDXJkezUaLbLispIVpoAYnnsmDEYDmU9CYKxVa9P24EUVATHzBwcB0wLgBCNePfr8yz0MlaqNAD85vqsyneVPS7Kwbr-VN-GOepWWEZZy-Kbq');
 
    sender.send(message, {
        registrationTokens : devices
    }, function(err, response) {
        if (err) {
            console.error(err);
        } else {
            console.log(response);
        }
    });
}