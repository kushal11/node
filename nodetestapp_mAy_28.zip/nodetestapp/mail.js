function mail_send(receiver_email, message)
{
    var nodemailer = require('nodemailer');
    var transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 'kushal_arora@rvtechnologies.co.in',
        pass: 'kushal_arora@#RV'
      }
    });

    var mailOptions = {
        from: 'kushal_arora@rvtechnologies.co.in',
        to: receiver_email,
        subject: 'Sending Email using Node.js',
        text: message
    };

    transporter.sendMail(mailOptions, function(error, info){
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });

}

exports.mail_send = mail_send;
