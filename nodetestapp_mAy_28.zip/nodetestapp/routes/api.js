module.exports = function(app) {
    var mongoose = require('mongoose');
    var passport = require('passport');


    var config = require('../config/database');
    require('../config/passport')(passport);


    var express = require('express');
    var jwt = require('jsonwebtoken');

    var router = express.Router();

    var User = require("../models/user");
    var Book = require("../models/book");   
    var City = require("../models/city");   
    var Device = require("../models/device");   


    var todoList = require('../controllers/UserController');  

    // todoList Routes
    app.route('/api/signup')
        .post(todoList.signup);
    app.route('/api/signin')
        .post(todoList.signin);
    app.route('/api/users' ,passport.authenticate('jwt', { session: false }))
        .get(todoList.users);
    app.route('/api/get_users_by_address' ,passport.authenticate('jwt', { session: false }))
        .post(todoList.get_users_by_address);
    // module.exports = router;
    app.route('/api/user/:userId')
        .put(todoList.edit_a_user);
    app.route('/api/books' ,passport.authenticate('jwt', { session: false }))
        .get(todoList.books)
        .post(todoList.register_book);

    app.route('/api/login/facebook')
        .post(todoList.registerSocial);

    app.route('/api/addcity',passport.authenticate('jwt', { session: false }))
        .post(todoList.addcity);
    app.route('/api/getcity',passport.authenticate('jwt', { session: false }))
        .post(todoList.getcity);
    app.route('/api/adddevice',passport.authenticate('jwt', { session: false }))
        .post(todoList.adddevice);
    app.route('/api/send_notification',passport.authenticate('jwt', { session: false }))
        .get(todoList.send_notification);

};




 getToken = function (headers) {
    if (headers && headers.authorization) {
        var parted = headers.authorization.split(' ');
        if (parted.length === 2) {
            return parted[1];
        } else {
            return null;
        }
    } else {
        return null;
    }
};

